## Lab Setup
Use MySQL or PostgreSQL locally. Run the .sql files in order.