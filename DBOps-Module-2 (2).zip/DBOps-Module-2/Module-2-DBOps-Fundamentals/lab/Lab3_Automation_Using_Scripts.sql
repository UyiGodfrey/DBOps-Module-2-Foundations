-- Automated script
ALTER TABLE users ADD age INT;