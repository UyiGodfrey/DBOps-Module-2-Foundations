## Glossary
**DBOps**: Database Operations Automation.
**Rollback**: Reverting a change.