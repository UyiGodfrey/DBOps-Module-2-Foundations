## Summary Notes
This file will contain summarized learnings from Module 2.